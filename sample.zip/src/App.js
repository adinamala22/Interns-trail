import React from 'react';
import Home from './Home';
import 'C:\\Users\\schandras5\\sample\\src\\App.css';
import '../src/Home';
function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}

export default App;
