package com.example.MothersDB;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MothersDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(MothersDbApplication.class, args);
	}

}
